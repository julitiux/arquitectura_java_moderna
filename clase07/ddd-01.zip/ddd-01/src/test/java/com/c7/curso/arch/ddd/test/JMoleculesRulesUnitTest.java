package com.c7.curso.arch.ddd.test;

import static org.assertj.core.api.Assertions.*;

import com.tngtech.archunit.core.domain.*;
import com.tngtech.archunit.junit.*;
import com.tngtech.archunit.lang.*;

//import org.jmolecules.archunit.*;

@AnalyzeClasses(packages = "com.c7")
class JMoleculesRulesUnitTest {

//    @ArchTest ArchRule dddRules = JMoleculesDddRules.all();
//    @ArchTest ArchRule onion = JMoleculesArchitectureRules.ensureOnionSimple();
//
//
//
//    @ArchTest
//    void detectsViolations(JavaClasses classes) {
//
//        EvaluationResult result = JMoleculesDddRules.all().evaluate(classes);
//
//        assertThat(result.hasViolation()).isFalse();
//    }
}
