package com.c7.curso.arch.ddd;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
