package com.c7.curso.arch.ddd.dominio.orden;

public enum EstadoOrden {
    PENDIENTE,
    COMPLETADA,
    CANCELADA;
}
