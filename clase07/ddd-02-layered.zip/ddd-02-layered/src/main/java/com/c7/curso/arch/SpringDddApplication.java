package com.c7.curso.arch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDddApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDddApplication.class, args);
	}

}
