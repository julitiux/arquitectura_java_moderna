@DomainLayer
package com.c7.curso.arch.ddd.borrow.model;

import org.jmolecules.architecture.layered.DomainLayer;