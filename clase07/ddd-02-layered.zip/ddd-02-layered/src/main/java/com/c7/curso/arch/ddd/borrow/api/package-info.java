@InterfaceLayer
package com.c7.curso.arch.ddd.borrow.api;

import org.jmolecules.architecture.layered.InterfaceLayer;