@InfrastructureLayer
package com.c7.curso.arch.ddd.borrow.infra;

import org.jmolecules.architecture.layered.InfrastructureLayer;