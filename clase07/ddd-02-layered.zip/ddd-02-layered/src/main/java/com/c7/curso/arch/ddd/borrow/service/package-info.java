@ApplicationLayer
package com.c7.curso.arch.ddd.borrow.service;

import org.jmolecules.architecture.layered.ApplicationLayer;