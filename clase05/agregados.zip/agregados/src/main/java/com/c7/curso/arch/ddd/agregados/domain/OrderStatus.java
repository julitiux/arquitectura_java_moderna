package com.c7.curso.arch.ddd.agregados.domain;

public enum OrderStatus {
    NEW, CONFIRMED, CANCELLED
}

